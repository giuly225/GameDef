// Variabili globali per le immagini
let playerImg, obstacleImg, waterImg, medicineImg, foodImg;

// Variabili globali per il gioco
let player, obstacles = [];
let waters = [], medicines = [], foods = [];
let score = 0;
let waterCount = 0, medicineCount = 0, foodCount = 0;
let gameOverButton;
let resetButtonY = 10; // Nuova variabile per la posizione Y del pulsante reset

function preload() {
  // Carica le immagini
  playerImg = loadImage('elementi/personaggio.png');
  obstacleImg = loadImage('elementi/bomba.png');
  waterImg = loadImage('elementi/acqua.png');
  medicineImg = loadImage('elementi/bende.png');
  foodImg = loadImage('elementi/cibo.png');
}

function setup() {
  createCanvas(800, 600);
  
  // Crea il pulsante di reset con ID per lo stile CSS
  let resetButton = createButton('Reset Partita');
  resetButton.position(width - 120, resetButtonY);
  resetButton.mousePressed(resetGame);
  resetButton.id('reset-button'); // Aggiungi ID al pulsante
  
  player = new Player();
  
  // Creiamo tre ostacoli
  for(let i = 0; i < 3; i++) {
    obstacles.push(new Obstacle());
  }
  
  // Crea gli oggetti raccolta
  waters = [];
  medicines = [];
  foods = [];
  
  // Inizializziamo 3 oggetti per ciascun tipo
  for (let i = 0; i < 3; i++) {
    waters.push(new Water());
    medicines.push(new Medicine());
    foods.push(new Food());
  }
}

function draw() {
  background(204, 255, 204);
  
  player.update();
  player.display();
  
  // Gestione multipli ostacoli
  for(let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].display();
    
    // Controllo collisione con ogni ostacolo
    if (player.collidesWith(obstacles[i])) {
      textSize(32);
      fill(0);
      text("Game Over", width / 2 - 100, height / 2);
      
      if (!gameOverButton) {
        gameOverButton = createButton('Torna al Bunker');
        gameOverButton.position(width/2 - 60, height/2 + 50);
        
        // Aggiungere l'evento click per la navigazione
        gameOverButton.mousePressed(() => {
          const url = 'bunker.html?' + 
            'score=' + score +
            '&water=' + waterCount +
            '&medicine=' + medicineCount +
            '&food=' + foodCount;
        window.location.href = url;
        });
        
        // Sposta il pulsante reset sotto al pulsante game over
        resetButtonY = height/2 + 100;
      }
      
      // Aggiorna la posizione del pulsante reset
      document.getElementById('reset-button').style.top = resetButtonY + 'px';
      
      noLoop();
    }
    
    // Reset ostacolo quando esce dallo schermo
    if (obstacles[i].y > height) {
      obstacles[i].reset();
      score++;
    }
  }
  
  // Gestiamo la raccolta degli oggetti
  // Acqua
  for (let i = waters.length - 1; i >= 0; i--) {
    waters[i].display();
    if (player.collidesWith(waters[i])) {
      waters.splice(i, 1);
      waterCount++;
      waters.push(new Water());
    }
  }

  // Medicinali
  for (let i = medicines.length - 1; i >= 0; i--) {
    medicines[i].display();
    if (player.collidesWith(medicines[i])) {
      medicines.splice(i, 1);
      medicineCount++;
      medicines.push(new Medicine());
    }
  }

  // Cibo
  for (let i = foods.length - 1; i >= 0; i--) {
    foods[i].display();
    if (player.collidesWith(foods[i])) {
      foods.splice(i, 1);
      foodCount++;
      foods.push(new Food());
    }
  }

  // Visualizza i contatori
  textSize(32);
  fill(0);
  text("Punteggio: " + score, 10, 40);
  text("Acqua: " + waterCount, 10, 80);
  text("Medicinali: " + medicineCount, 10, 120);
  text("Cibo: " + foodCount, 10, 160);
}

function resetGame() {
  // Reset dei contatori
  score = 0;
  waterCount = 0;
  medicineCount = 0;
  foodCount = 0;
  
  // Ripristina la posizione originale del pulsante reset
  resetButtonY = 10;
  document.getElementById('reset-button').style.top = resetButtonY + 'px';
  
  // Ricreazione del personaggio e degli ostacoli
  player = new Player();
  obstacles = [];
  for(let i = 0; i < 3; i++) {
    obstacles.push(new Obstacle());
  }
  
  // Svuotamento degli array che contengono gli oggetti
  waters = [];
  medicines = [];
  foods = [];
  
  // Creazione di 3 oggetti per ciascun tipo
  for (let i = 0; i < 3; i++) {
    waters.push(new Water());
    medicines.push(new Medicine());
    foods.push(new Food());
  }
  
  // Rimozione del pulsante "Game Over"
  if (gameOverButton) {
    gameOverButton.remove();
    gameOverButton = null;
  }
  
  // Ripristino del ciclo del gioco
  loop();
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 50;
  }

  update() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x + this.size < width) {
      this.x += 5;
    }
    if (keyIsDown(UP_ARROW) && this.y > 0) {
      this.y -= 5;
    }
    if (keyIsDown(DOWN_ARROW) && this.y + this.size < height) {
      this.y += 5;
    }
  }

  display() {
    image(playerImg, this.x, this.y, this.size, this.size);
  }

  collidesWith(obj) {
    return (
      this.x < obj.x + obj.size &&
      this.x + this.size > obj.x &&
      this.y < obj.y + obj.size &&
      this.y + this.size > obj.y
    );
  }
}

class Obstacle {
  constructor() {
    this.x = random(width - 50);
    this.y = -50;
    this.size = 70;
    this.speed = 2;
  }

  update() {
    this.y += this.speed;
  }

  display() {
    image(obstacleImg, this.x, this.y, this.size, this.size);
  }

  reset() {
    this.y = -this.size;
    this.x = random(width - this.size);
    this.size *= 1.05;
  }
}

class Water {
  constructor() {
    this.size = 50;
    this.x = random(this.size, width - this.size);
    this.y = random(this.size, height - this.size);
  }

  display() {
    image(waterImg, this.x, this.y, this.size, this.size);
  }
}

class Medicine {
  constructor() {
    this.size = 50;
    this.x = random(this.size, width - this.size);
    this.y = random(this.size, height - this.size);
  }

  display() {
    image(medicineImg, this.x, this.y, this.size, this.size);
  }
}

class Food {
  constructor() {
    this.size = 50;
    this.x = random(this.size, width - this.size);
    this.y = random(this.size, height - this.size);
  }

  display() {
    image(foodImg, this.x, this.y, this.size, this.size);
  }
}